/** Automatically generated file. DO NOT MODIFY */
package com.javatpoint.hidetitle;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}