/** Automatically generated file. DO NOT MODIFY */
package com.example.simplecamera;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}