/** Automatically generated file. DO NOT MODIFY */
package com.example.rating;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}